import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://realtimeattendance-f3a89-default-rtdb.firebaseio.com/"
})

ref = db.reference('Students')

data = {
    "1231":
        {
            "Name": "ElonMusk",
            "Major": "AI",
            "Starting_Year": 2020,
            "Total_Attendance": 8,
            "Standing": "BOY",
            "Year": "2",
            "Last_Attendance_Time": "2022-12-11 00:54:34"

        },
    "1232":
        {
            "Name": "Ranveer Shing",
            "Major": "Actor",
            "Starting_Year": 2020,
            "Total_Attendance": 8,
            "Standing": "BOY",
            "Year": "4",
            "Last_Attendance_Time": "2022-12-11 00:54:34"

        },
    "1233":
        {
            "Name": "Narendra Modi",
            "Major": "PrimMinister",
            "Starting_Year": 2020,
            "Total_Attendance": 12,
            "Standing": "BOY",
            "Year": "2",
            "Last_Attendance_Time": "2022-12-11 00:54:34"

        },
    "1234":
        {
            "Name": "Ashish Mourya",
            "Major": "Student",
            "Starting_Year": 2022,
            "Total_Attendance": 12,
            "Standing": "BOY",
            "Year": "2",
            "Last_Attendance_Time": "2022-12-11 00:54:40"

        },
    "1235":
        {
            "Name": "Lovely ",
            "Major": "Student",
            "Starting_Year": 2022,
            "Total_Attendance": 9,
            "Standing": "Girl",
            "Year": "2",
            "Last_Attendance_Time": "2022-12-11 00:54:40"

        }

}

for key, value in data.items():
    ref.child(key).set(value)
